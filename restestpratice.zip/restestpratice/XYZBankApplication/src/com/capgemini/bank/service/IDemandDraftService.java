package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.DemandDraftException;

public interface IDemandDraftService 
{
	public String addDraftDetails(DemandDraft demanddraftbean) throws DemandDraftException;
	public DemandDraft viewDraftDetails(String transaction_id) throws DemandDraftException;
}