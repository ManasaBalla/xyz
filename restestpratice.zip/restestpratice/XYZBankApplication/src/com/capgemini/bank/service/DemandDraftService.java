package com.capgemini.bank.service;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exception.DemandDraftException;

public class DemandDraftService implements IDemandDraftService {
	
	
	IDemandDraftDAO demanddraftDao;
	
	public String addDraftDetails(DemandDraft demanddraftbean) throws DemandDraftException{
		
		/*// Input validation Logic         
		try{
			if(!(Pattern.matches("[A-Z a-z]+",demanddraftDao.getCustomer_name()))){
				throw new DemandDraftException("Name contains invalid characters");
			}
			if(!(Pattern.matches("[0-9]{10}+",demanddraftDao.getPhone_number()))){
				throw new DemandDraftException("Mobile Number has invalid characters/invalid length");
			}
			if(demanddraftDao.getDd_amount()<=0){
				throw new DemandDraftException("Invalid amount"); 
			}
		}catch(DemandDraftException e){
			System.err.println(e.getMessage());
			
			System.exit(0);
		}*/
		// End of Input validation Logic       
		
		
		// Commission calculation
		
		int dd_commission = 0;
		try{
			int am = demanddraftbean.getDd_amount();
			dd_commission = 0;
			if(am<=5000){
				dd_commission = 10;
			}else if(am>5000 && am<=10000){
				dd_commission = 41;
			}else if(am>10000 && am<=100000){
				dd_commission = 51;
			}else if(am>100000 && am<=500000){
				dd_commission = 306;
			}else{
				throw new DemandDraftException("DD Amount should be less than Rs.5,00,000");
			}
		}catch(DemandDraftException e){
			System.err.println(e.getMessage());
			
			System.exit(0);
		}
		// End of Commission calculation
		
		demanddraftbean.setDd_commission(dd_commission);
		
		
		// SERVICE LAYER TO DAO LAYER
		DemandDraftDAO dao = new DemandDraftDAO();
		String transaction_id = dao.addDraftDetails(demanddraftbean);
		
		return transaction_id;
		
	}
	public DemandDraft getDemandDraftDetails (int transactionId){
		
		
		return null; 
		
	}
	public void validateDemandDraft(DemandDraft demanddraftDao)throws DemandDraftException {
		// TODO Auto-generated method stub
		
	}
	@Override
	public DemandDraft viewDraftDetails(String transaction_id) throws DemandDraftException {
		demanddraftDao=new DemandDraftDAO();
		DemandDraft demanddraftbean=null;
		demanddraftbean=demanddraftDao.viewDraftDetails(transaction_id);
		return demanddraftbean;
	}
	public boolean validateDraftId(String transaction_id) {
		Pattern idPattern = Pattern.compile("[0-9]{1,6}");
		Matcher idMatcher = idPattern.matcher(transaction_id);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}
	}
	
	


