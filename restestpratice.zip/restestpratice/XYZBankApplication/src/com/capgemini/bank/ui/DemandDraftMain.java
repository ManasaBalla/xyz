package com.capgemini.bank.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.DemandDraftException;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;

public class DemandDraftMain {

	static Scanner sc = new Scanner(System.in);
	static IDemandDraftService idemandraftService = null;
	static DemandDraftService demanddraftService = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources//log4j.properties");
		DemandDraft demanddraftbean = null;

		String transaction_id = null;
		int option = 0;

		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   XYZ Bank   ");
			System.out.println("_______________________________\n");

			System.out.println("1.Enter Demand Draft Details ");
			System.out.println("2.Print Demand Draft");
			System.out.println("3.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					while (demanddraftbean == null) {
						demanddraftbean = populateDemandDraft();
						// System.out.println(donorBean);
					}

					try {
						demanddraftService = new DemandDraftService();
						transaction_id = demanddraftService.addDraftDetails(demanddraftbean);

						System.out.println("Donator details  has been successfully registered ");
						System.out.println("Donator  ID Is: " + transaction_id);

					} catch (DemandDraftException DemandDraftException) {
						logger.error("exception occured", DemandDraftException);
						System.out.println("ERROR : "
								+ DemandDraftException.getMessage());
					} finally {
						transaction_id = null;
						demanddraftService = null;
						demanddraftbean = null;
					}

					break;
					
				case 2:

					demanddraftService = new DemandDraftService();

					System.out.println("Enter numeric donor id:");
					transaction_id = sc.next();

					while (true) {
						if (demanddraftService.validateDraftId(transaction_id)) {
							break;
						} else {
							System.err
									.println("Please enter numeric transaction id only, try again");
							transaction_id = sc.next();
						}
					}

					demanddraftbean = getDraftDetails(transaction_id);

					if (demanddraftbean != null) {
						System.out.println("Customer_name             :"
								+ demanddraftbean.getCustomer_name());
						System.out.println("In_favor_of          :"
								+ demanddraftbean.getIn_favor_of());
						System.out.println("Phone Number     :"
								+ demanddraftbean.getPhone_number());
						System.out.println("Date_of_transaction       :"
								+ demanddraftbean.getDate_of_transaction());
						System.out.println("Amount       :"
								+ (demanddraftbean.getDd_amount()+demanddraftbean.getDd_commission()));
						System.out.println("Dd_description()  :"
								+ demanddraftbean.getDd_description());
					} else {
						System.err
								.println("There are no donation details associated with donor id "
										+ transaction_id);
					}

					break;
		
		
				case 3:

					System.out.print("Exit Trust Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}// end of while
	}// end of try

	/*
	 * This function will call the service layer method and return the bean
	 * object which is populated by the information of the given donorId in
	 * parameter
	 */
	private static DemandDraft getDraftDetails(String transaction_id) {
		DemandDraft demanddraftbean = null;
		idemandraftService = new DemandDraftService();

		try {
			demanddraftbean = idemandraftService.viewDraftDetails(transaction_id);
		} catch (DemandDraftException demanddraftException) {
			logger.error("exception occured ", demanddraftException);
			System.out.println("ERROR : " + demanddraftException.getMessage());
		}

		idemandraftService = null;
		return demanddraftbean;
	}

	
	/* * This function will be called by main and will return a validated bean
	 * object OR null if details are invalid*/
	 
	private static DemandDraft populateDemandDraft() {

		// Reading and setting the values for the demanddraftbean
		
		DemandDraft demanddraftbean = new DemandDraft();;

		System.out.println("\n Enter Details");

		System.out.println("Enter customer name: ");
		demanddraftbean.setCustomer_name(sc.next());

		System.out.println("In favor of: ");
		demanddraftbean.setIn_favor_of(sc.next());

		System.out.println("Enter phone number: ");
		demanddraftbean.setPhone_number(sc.next());
		
		System.out.println("Enter DD amount");
		demanddraftbean.setDd_amount(sc.nextInt());
		

		
		System.out.println("DD Description");
		demanddraftbean.setDd_description(sc.next());
		
		demanddraftService = new DemandDraftService();

		try {
			demanddraftService.validateDemandDraft(demanddraftbean);
			return demanddraftbean;
		} catch (DemandDraftException demanddraftException) {
			logger.error("exception occured", demanddraftException);
			System.err.println("Invalid data:");
			System.err.println(demanddraftException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
}

